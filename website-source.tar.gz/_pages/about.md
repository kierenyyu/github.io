---
layout: single
title: "Kieren Yu"
permalink: /
author_profile: true
excerpt: "Ph.D. student at HKUST(GZ), studying EEG foundation models, brain decoding, and wearable neural sensing."
---

<p class="intro-role">Ph.D. student · Internet of Things · HKUST(GZ)</p>

<p class="intro-lead">Learning useful representations from brain signals, and building better ways to evaluate them.</p>

I am a Ph.D. student in the [Internet of Things Thrust](https://iott.hkust-gz.edu.cn/) at [The Hong Kong University of Science and Technology (Guangzhou)](https://www.hkust-gz.edu.cn/), supervised by [Prof. Kaishun Wu](https://scholar.google.com/citations?user=Vt-q3E4AAAAJ) and co-supervised by [Prof. Jintai Chen](https://scholar.google.com/citations?user=ZiY3xYEAAAAJ). Before that, I completed my undergraduate studies in Automation at Tsinghua University.

My research interests center on EEG representation learning and brain–computer interfaces. I am interested in how models learn from neural signals, how these representations connect to visual concepts, and how evaluation can reveal what a model actually learns. I also work on wearable EEG for affective and cognitive sensing.

## Research interests

<div class="interest-list">
  <div><h3>EEG foundation models</h3><p>Self-supervised objectives and transferable neural representations.</p></div>
  <div><h3>Brain–vision decoding</h3><p>Connecting EEG with images, text, and structured visual concepts.</p></div>
  <div><h3>Benchmarks and neural agents</h3><p>Reproducible evaluation and reasoning grounded in signal evidence.</p></div>
  <div><h3>Wearable neural sensing</h3><p>Ear-EEG interfaces for affective and cognitive load assessment.</p></div>
</div>

Explore [NSP, ProtoEEG, Neural-Agent-BENCH, EEGVIS-BENCH, and Ear-EmoLoad]({{ '/research/' | relative_url }}) on the Research page.

<div class="section-heading"><h2>Selected publications</h2><a href="{{ '/publications/' | relative_url }}">Publication list →</a></div>

{% include publication-list.html compact=true %}

## Education

<div class="education-item">
  <h3>The Hong Kong University of Science and Technology (Guangzhou)</h3>
  <p>Ph.D. studies, Internet of Things · Supervisor: <a href="https://scholar.google.com/citations?user=Vt-q3E4AAAAJ">Prof. Kaishun Wu</a> · Co-supervisor: <a href="https://scholar.google.com/citations?user=ZiY3xYEAAAAJ">Prof. Jintai Chen</a></p>
  <time>2023–present</time>
</div>
<div class="education-item">
  <h3>Tsinghua University</h3>
  <p>Undergraduate studies, Automation</p>
  <time>2018–2023</time>
</div>

## Academic service

Conference reviewer: AAAI 2026, AAAI 2027, ICLR 2027.

## Get in touch

For research discussions and potential collaborations, reach me at [{{ site.author.email }}](mailto:{{ site.author.email }}).

<p class="subtle">Homepage visitors: <span id="busuanzi_page_uv">unavailable</span> · Page views: <span id="busuanzi_page_pv">unavailable</span></p>
<script defer src="https://cdn.busuanzi.cc/busuanzi/3.6.9/busuanzi.min.js"></script>
