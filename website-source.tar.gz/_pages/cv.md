---
layout: single
title: "Curriculum vitae"
permalink: /cv/
author_profile: true
excerpt: "Education, research interests, and selected publications of Kieren Yu."
---

Kieren Yu · Ph.D. student, Internet of Things<br>
The Hong Kong University of Science and Technology (Guangzhou)<br>
[{{ site.author.email }}](mailto:{{ site.author.email }}) · [Google Scholar]({{ site.author.googlescholar }}) · [ORCID]({{ site.author.orcid }}) · [LinkedIn](https://www.linkedin.com/in/{{ site.author.linkedin }}/)

## Education

<div class="education-item">
  <h3>The Hong Kong University of Science and Technology (Guangzhou)</h3>
  <p>Ph.D. studies in Internet of Things</p>
  <p>Advisor: <a href="https://www.hkust-gz.edu.cn/people/wu-kaishun/">Prof. Kaishun Wu</a></p>
  <time>2023–present</time>
</div>
<div class="education-item">
  <h3>Tsinghua University</h3>
  <p>Undergraduate studies in Automation</p>
  <time>2018–2023</time>
</div>

## Research interests

- EEG foundation models and self-supervised representation learning
- EEG-to-image decoding and multimodal alignment
- Reproducible benchmarks and signal-grounded neural agents
- Wearable ear-EEG, affective computing, and cognitive load assessment

## Selected publications

{% include publication-list.html compact=true %}

## Research projects

{% for project in site.data.projects %}
- [**{{ project.name }}**]({{ '/research/' | relative_url }}#{{ project.id }}) — {{ project.title }}
{% endfor %}
