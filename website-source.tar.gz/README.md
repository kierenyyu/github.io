# Kieren Yu — academic website

Personal academic website built with [Academic Pages](https://github.com/academicpages/academicpages.github.io) and Jekyll.

## Content

- `_config.yml`: identity, academic profiles, and planned public URL.
- `_pages/about.md`: biography, research interests, and education.
- `_pages/research.html` + `_data/projects.yml`: research projects.
- `_pages/publications.html` + `_data/selected_publications.yml`: selected papers.
- `_pages/cv.md`: web CV.
- `files/publications.bib`: bibliography; keep in sync with the publication data.
- `_sass/academic.scss`: personal styling on top of the Academic Pages theme.
- `_data/navigation.yml`: site navigation.

No portrait or downloadable CV is included yet. To add a portrait, place the image in `images/` and set `author.avatar` to its filename.

## Local development

With Ruby and Bundler installed:

```bash
bundle install
bundle exec jekyll build --strict_front_matter
bundle exec jekyll serve --host 127.0.0.1 --config _config.yml,_config_local.yml
```

In the original RESEARCH workspace, the parent project provides a local runtime and `tools/site.sh` for install, build, and preview. See `../README.md`.

## Publication and project updates

The publication list matches the three Google Scholar entries checked on September 10, 2026. It is maintained manually. Verify authors, publication status, year, and URLs before adding a record. Research projects are presented separately from publications.

## GitHub Pages

The website is configured for https://kierenyyu.github.io/github.io/ and the existing repository `kierenyyu/github.io`.

In the repository's **Settings → Pages → Build and deployment**, select **GitHub Actions** as the source. The `Deploy academic website` workflow builds with Ruby 3.3.6 and the committed `Gemfile.lock`, then deploys only `_site/`. It runs when changes are pushed to `master` and can also be started from the Actions tab.

Update the source files above, build locally, commit the changes, and push to `master` to update the public website. Check the Actions run and the live URL to confirm publication. Only this website directory belongs in the repository; the parent information forms, runtime, archives, and QA files are not site content.

## Attribution

Based on Academic Pages / Minimal Mistakes. The upstream MIT license is retained in `LICENSE`.
